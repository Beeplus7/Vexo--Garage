import Stripe from 'stripe';

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20',
});

export const VEXO_COMMISSION = {
  base: 450, // £4.50 10%
  shield: 200, // £2.00
  passport: 100, // £1.00
  total: 750, // £7.50
};

export const GARAGE_SHARE = 4050; // £40.50 90% of £45 MOT