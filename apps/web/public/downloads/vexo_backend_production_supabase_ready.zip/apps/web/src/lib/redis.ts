import Redis from 'ioredis';

export const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379', {
  maxRetriesPerRequest: 3,
});

export const CACHE_TTL = {
  vehicle: 60 * 60 * 24, // 24h
  mot: 60 * 60 * 12, // 12h
  postcode: 60 * 60 * 24 * 30, // 30d
  garages: 60 * 5, // 5m
};